import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ifi-gla-web';
 /** title = 'ifi_gla'; */
  showEtudiants = true;
  showConfig = true;
  showDownloader = true;
  showUploader = true;
  showSearch = true;
  showAddetudiants = true;
  toggleEtudiants() { this.showEtudiants = !this.showEtudiants; };
  toggleConfig() { this.showConfig = !this.showConfig; };
  toggleDownloader() { this.showDownloader = !this.showDownloader; };
  toggleUploader() { this.showUploader = !this.showUploader; };
  toggleSearch() { this.showSearch = !this.showSearch; };
  toggleAddetudiants() { this.showAddetudiants = !this.showAddetudiants; };
}
