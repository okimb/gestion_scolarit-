import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { HttpErrorHandler, HandleError } from '../http-error-handler.service';

export interface Info {
  bourses: string;
  formation: string;
  contact: string;
}

export const searchUrl = 'http://ifi.edu.vn';

const httpOptions = {
  headers: new HttpHeaders({
    'x-refresh':  'true'
  })
};

function createHttpOptions(ifi: string, refresh = false) {
    // npm package name search api
    // e.g., http://npmsearch.com/query?q=dom'
    const params = new HttpParams({ fromObject: { q: ifi } });
    const headerMap = refresh ? {'x-refresh': 'true'} : {};
    const headers = new HttpHeaders(headerMap) ;
    return { headers, params };
}

@Injectable()
export class PackageSearchService {
  private handleError: HandleError;

  constructor(
    private http: HttpClient,
    httpErrorHandler: HttpErrorHandler) {
    this.handleError = httpErrorHandler.createHandleError('EtudiantsService');
  }

  search (ifi: string, refresh = false): Observable<Info[]> {
    // clear if no pkg name
    if (!ifi.trim()) { return of([]); }

    const options = createHttpOptions(ifi, refresh);

    // TODO: Add error handling
    return this.http.get(searchUrl, options).pipe(
      map((data: any) => {
        return data.results.map(entry => ({
            bourses: entry.bourses[0]
            //formation: entry.formation[0],
            // contact: entry.contact[0]
          } as Info )
        );
      }),
      catchError(this.handleError('search', []))
    );
  }
}
