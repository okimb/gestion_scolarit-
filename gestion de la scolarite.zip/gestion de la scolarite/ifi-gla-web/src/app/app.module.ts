import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { EtudiantsComponent } from './etudiants/etudiants.component';
import {FormsModule} from '@angular/forms';
import {HttpClientModule, HttpClientXsrfModule} from '@angular/common/http';



import { RequestCache, RequestCacheWithMap } from './request-cache.service';

import { AuthService } from './auth.service';
/* import { ConfigComponent } from './config/config.component'; */
import { DownloaderComponent } from './downloader/downloader.component';
import { HttpErrorHandler } from './http-error-handler.service';
import { MessageService } from './message.service';
import { MessagesComponent } from './messages/messages.component';
import { PackageSearchComponent } from './package-search/package-search.component';



// import { RequestCache, RequestCacheWithMap } from './request-cache.service';

import { httpInterceptorProviders } from './http-interceptors/index';
import {EtudiantsService} from './etudiants/etudiants.service';
import { AddetudiantsComponent } from './etudiants/addetudiants.component';
import { UploaderComponent } from './uploader/uploader.component';
import { ConfigComponent } from './config/config.component';



@NgModule({
  declarations: [
    AppComponent,
    EtudiantsComponent,
   // AddetudiantsComponent,
   /* ConfigComponent, */
    DownloaderComponent,
    MessagesComponent,
   //UploaderComponent,
    PackageSearchComponent,
   AddetudiantsComponent,
   UploaderComponent,
   ConfigComponent,
   // AddEtudiantsComponent,
  ],
  imports: [
    BrowserModule, FormsModule, HttpClientModule,
    HttpClientXsrfModule.withOptions({
      cookieName: 'My-Xsrf-Cookie',
      headerName: 'My-Xsrf-Header',
    }),

    // The HttpClientInMemoryWebApiModule module intercepts HTTP requests
    // and returns simulated server responses.
    // Remove it when a real server is ready to receive requests.
   /* HttpClientInMemoryWebApiModule.forRoot(
    InMemoryDataService, {
        dataEncapsulation: false,
        passThruUnknownUrl: true,
        put204: false // return entity after PUT/update
      }
    )*/
  ],
  providers: [
    AddetudiantsComponent,
    EtudiantsService,
    EtudiantsComponent,
   AuthService,
   HttpErrorHandler,
   MessageService,
    { provide: RequestCache, useClass: RequestCacheWithMap }
   // httpInterceptorProviders */
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
