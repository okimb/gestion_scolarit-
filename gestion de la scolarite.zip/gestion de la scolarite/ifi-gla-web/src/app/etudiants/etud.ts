export class Etud {
  id_etd: number;
  nom_etd: string;
  prenom_etd: string;
  date_nais_etd: string;
  mail_etd: string;
  tel_etd: string;
  lib_add_etd: string;
  adresse_etd: {
    libelle_adr: string;
  };
}
