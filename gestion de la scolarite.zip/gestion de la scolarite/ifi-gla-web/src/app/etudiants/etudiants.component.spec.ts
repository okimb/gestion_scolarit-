import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EtudiantsComponent } from './etudiants.component';
// @ts-ignore
import {describe} from 'jasmine';
// @ts-ignore
import {expect} from 'jasmine';

describe('EtudiantsComponent', () => {
  let component: EtudiantsComponent;
  let fixture: ComponentFixture<EtudiantsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EtudiantsComponent ]
    })
    .compileComponents();
  }));

  // @ts-ignore
  beforeEach(() => {
    fixture = TestBed.createComponent(EtudiantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // @ts-ignore
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
