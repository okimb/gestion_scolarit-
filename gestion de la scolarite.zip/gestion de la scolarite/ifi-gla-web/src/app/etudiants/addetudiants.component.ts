import { Component, OnInit } from '@angular/core';
import {Etud} from './etud';
import {EtudiantsService} from './etudiants.service';
import {Router} from '@angular/router';


@Component({
  selector: 'app-addet',
  templateUrl: './addetudiants.component.html',
  styleUrls: ['./etudiants.component.css']
})
export class AddetudiantsComponent {

  etutiant: Etud = new class implements Etud {
    adresse_etd: { libelle_adr: string };
    date_nais_etd: string;
    id_etd: number;
    mail_etd: string;
    nom_etd: string;
    prenom_etd: string;
    tel_etd: string;
    lib_add_etd: string;
  }
  constructor(private etudiantsService: EtudiantsService) { }
  private etudUrl = 'http://localhost:8082/etudiants';
 /* createEtudiant(): void {
    this.etudiantsService.createEtudiant(this.etutiant)
      .subscribe( data => {
        alert("User created successfully.");
      });

  }; */
 /*

  createEtudiant(): void {
    var nom_etd=document.getElementById("nom_etd").value;
    var pren=document.getElementById("prenom_etd").value;
    var datns =document.getElementById("date_nais_etd").value;
    var addremai =document.getElementById("mail_etd").value;
    var tele =document.getElementById("tel_etd").value;
    var addresse=document.getElementById("lib_add_etd").value;
    // var addet =document.getElementById("libelle_adr").value;
    this.etutiant.nom_etd=nom_etd;
    this.etutiant.prenom_etd=pren;
    this.etutiant.date_nais_etd=datns;
    this.etutiant.mail_etd=addremai;
    this.etutiant.tel_etd=tele;
    this.etutiant.lib_add_etd=addresse;
    // this.etutiant.adresse_etd.libelle_adr=addet;
    this.etudiantsService.createEtudiant(this.etutiant)
      .subscribe( data => {
        alert("Depot avec succé.");
      });

  };
  //*/

}
