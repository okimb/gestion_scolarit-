import {Component, OnInit, Inject} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { NgModule } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AddetudiantsComponent} from './addetudiants.component';
import {d} from '@angular/core/src/render3';
import {subscribeOn} from 'rxjs/operators';
import {nextTick} from 'q';
import {Observable} from 'rxjs';

import { Etud } from './etud';
import { EtudiantsService } from './etudiants.service';
import {all} from 'codelyzer/walkerFactory/walkerFn';
import {url} from 'inspector';
import {Router} from '@angular/router';


@Component({
  selector: 'app-et',
  templateUrl: './etudiants.component.html',
 providers: [EtudiantsService],
  styleUrls: ['./etudiants.component.css']
})
export class EtudiantsComponent implements OnInit {
  etutiant: Etud = new class implements Etud {
    adresse_etd: { libelle_adr: string };
    date_nais_etd: string;
    id_etd: number;
    mail_etd: string;
    nom_etd: string;
    prenom_etd: string;
    tel_etd: string;
    lib_add_etd: string;
  };
  etudiant: Etud = new class implements Etud {
    adresse_etd: { libelle_adr: string };
    date_nais_etd: string;
    id_etd: number;
    mail_etd: string;
    nom_etd: string;
    prenom_etd: string;
    tel_etd: string;
    lib_add_etd: string;
  }

  etudiants: Etud[];
  editEtud: Etud; // the etud currently being edited
    listEtudiants;
    listAdresses;
  constructor(private etudiantsService: EtudiantsService) { }
 //constructor(private httpClient: HttpClient) { }

  ngOnInit() {
     /*this.httpClient.get('http://localhost:8082/etudiants')
      .subscribe(data => {
        this.listEtudiants = data;
      }, err => {
        console.log(err);
      });
    this.httpClient.get('http://localhost:8082/adresses')
      .subscribe(data => {
        this.listAdresses = data;
      }, err => {
        console.log(err);
      });
*/
    this.etudiantsService.getEtudiants()
      .subscribe( data => {
        this.listEtudiants = data;
      }, err => {
      console.log(err);
    });

  }

  add_Etudiants(nom_etd: string, prenom_etd: string, date_nais_etd: string, mail_etd: string, tel_etd: string, lib_add_etd, libelle_adr: string): void {
    nom_etd = nom_etd.trim();
    prenom_etd = prenom_etd.trim();
    date_nais_etd = date_nais_etd.trim();
    mail_etd = mail_etd.trim();
    tel_etd = tel_etd.trim();
    lib_add_etd = lib_add_etd.trim();
    libelle_adr = libelle_adr.trim();


    if (!nom_etd&&!prenom_etd&&!date_nais_etd) { return; }
        this.etudiantsService.save_etudiants({nom_etd, prenom_etd, date_nais_etd, mail_etd, tel_etd, lib_add_etd} as Etud)
      .subscribe(etud => {
        this.etudiants.push(etud);
      });
  }


  getEtudiants(): void{
    this.etudiantsService.getEtudiants()
      .subscribe(etudiants => this.etudiants=etudiants);
  }

  delete_etudiants(etud: Etud): void{
    this.etudiants=this.etudiants.filter(e =>e!==etud);
    this.etudiantsService.delete_etudiants(etud.id_etd).subscribe();
    // this.etudiantsService.delete_etudiants(etud.id_etd);
  }

  deleteEtudiant(etud: Etud): void {
    this.etudiantsService.deleteEtudiant(etud)
      .subscribe( data => {
        this.etudiants = this.etudiants.filter(e=>e !==etud);
      })
  };

  editEudiant(etud: Etud): void {
    window.localStorage.removeItem("editEtudId_etd");
    window.localStorage.setItem("editEtudId_etd", etud.id_etd.toString());
    this.editEudiant(etud);
    //this.router.navigate(['editEtud']);
  };
  edit(etud) {
    this.editEtud=etud;
  }
  search_etudiants(searchTerm){
   // var searchTerm=document.getElementById("id_etd").value;
    this.etutiant.id_etd=searchTerm;
    this.editEtud=undefined;
    if(searchTerm){
      this.etudiantsService.searchEtudiants(searchTerm.value)
        .subscribe(etudants=>this.etudiants=etudants);

    }
  }
  update_etudiants(){
    if (this.editEtud){
      this.etudiantsService.update_etudiants(this.editEtud)
        .subscribe(etud=>{
          const ix=etud?this.etudiants.findIndex(e=>e.id_etd===etud.id_etd):-1;
          if (ix>-1){this.etudiants[ix]=etud;}
        })
      this.editEtud=undefined;
    }

  }
/*
  createEtudiant(): void {
    var nom_etd=document.getElementById("nom_etd").value;
    var pren=document.getElementById("prenom_etd").value;
    var datns =document.getElementById("date_nais_etd").value;
    var addremai =document.getElementById("mail_etd").value;
    var tele =document.getElementById("tel_etd").value;
    var addresse=document.getElementById("lib_add_etd").value;
    // var addet =document.getElementById("libelle_adr").value;
    this.etutiant.nom_etd=nom_etd;
    this.etutiant.prenom_etd=pren;
    this.etutiant.date_nais_etd=datns;
    this.etutiant.mail_etd=addremai;
    this.etutiant.tel_etd=tele;
    this.etutiant.lib_add_etd=addresse;
    // this.etutiant.adresse_etd.libelle_adr=addet;
    this.etudiantsService.createEtudiant(this.etutiant)
      .subscribe( data => {
        alert("User created successfully.");
      });

  };

  // */

}

