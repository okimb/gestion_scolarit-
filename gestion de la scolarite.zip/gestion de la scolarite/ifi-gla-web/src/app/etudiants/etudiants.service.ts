import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';


import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Etud } from './etud';
import { HttpErrorHandler, HandleError } from '../http-error-handler.service';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};

@Injectable({
  providedIn: 'root',
})

export class EtudiantsService {
  //etudiantsUrl = 'api/etudiants';  // URL to web api
  //etudiantsUrl = 'http://localhost:8082/etudiants';  // URL to web api
  private etudiantsUrl = 'http://localhost:8082/etudiants';
  //etudiantsUrl_save_etd = 'http://localhost:8082/save_etudiants';  // URL to web api */
  private handleError: HandleError;

 /* constructor(
    //private httpClient: HttpClient,
   // private http: HttpClient,
    httpErrorHandler: HttpErrorHandler) {
    this.handleError = httpErrorHandler.createHandleError('EtudiantsService');
  }*/
  constructor(private http:HttpClient) {}
  /** GET etudiants from the server */
  getEtudiants (): Observable<Etud[]> {
    //return this.http.get<User[]>(this.userUrl);
    return this.http.get<Etud[]>(this.etudiantsUrl);
      /*.pipe(
        catchError(this.handleError('getEtudiants', []))
      );*/
  }

  // /* GET etudiants whose name contains search term */
  searchEtudiants(term: string): Observable<Etud[]> {
    term = term.trim();

    // Add safe, URL encoded search parameter if there is a search term
    const options = term ?
     { params: new HttpParams().set('id_etd', term) } : {};

    return this.http.get<Etud[]>(this.etudiantsUrl, options)
      .pipe(
        catchError(this.handleError<Etud[]>('searchEtudiants', []))
      );
  }

  //////// Save methods //////////

  /** POST: add a new etud to the database */
  save_etudiants (etud: Etud): Observable<Etud> {
    return this.http.post<Etud>(this.etudiantsUrl, etud, httpOptions)
      .pipe(
        catchError(this.handleError('save_etudiants', etud))
      );
  }

  /** DELETE: delete the Etud from the server */
  delete_etudiants (id_etd: number): Observable<{}> {
    const url = `${this.etudiantsUrl}/${id_etd}`; // DELETE api/etudiants/42
    return this.http.delete(url, httpOptions)
      .pipe(
        catchError(this.handleError('delete_etudiants'))
      );
  }

  public deleteEtudiant(etud: Etud) {
    return this.http.delete(this.etudiantsUrl + "/"+ etud.id_etd);
  }

  /** PUT: update the hero on the server. Returns the updated hero upon success. */
  update_etudiants (etud: Etud): Observable<Etud> {
    httpOptions.headers =
      httpOptions.headers.set('Authorization', 'my-new-auth-token');

    return this.http.put<Etud>(this.etudiantsUrl, etud, httpOptions)
      .pipe(
        catchError(this.handleError('update_etudiants', etud))
      );
  }

  /*
  createUser(etud: Etud): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.etudiantsUrl, etud);
  } */

  public createEtudiant(etud: Etud) {
    return this.http.post<Etud>(this.etudiantsUrl,etud);

  }

}
