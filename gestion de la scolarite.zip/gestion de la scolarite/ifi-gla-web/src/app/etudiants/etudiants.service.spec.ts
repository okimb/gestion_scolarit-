import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

// Other imports
// Other imports
import {getTestBed, TestBed} from '@angular/core/testing';
import { HttpClient, HttpResponse } from '@angular/common/http';

import { Etud } from './etud';
import { EtudiantsService } from './etudiants.service';
import { HttpErrorHandler } from '../http-error-handler.service';
import { MessageService } from '../message.service';
// @ts-ignore
import {describe} from 'jasmine';
// @ts-ignore
import {expect} from 'jasmine';
import {fail} from 'assert';


describe('EtudiantsService', () => {
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let etudService: EtudiantsService;

  // @ts-ignore
  beforeEach(() => {
    TestBed.configureTestingModule({
      // Import the HttpClient mocking services
      imports: [ HttpClientTestingModule ],
      // Provide the service-under-test and its dependencies
      providers: [
        EtudiantsService,
        HttpErrorHandler,
        MessageService
      ]
    });

    // Inject the http, test controller, and service-under-test
    // as they will be referenced by each test.
    httpClient = TestBed.get(HttpClient);
    httpTestingController = TestBed.get(HttpTestingController);
    etudService = TestBed.get(EtudiantsService);
  });

  // @ts-ignore
  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpTestingController.verify();
  });

  /// HeroService method tests begin ///

  describe('#getEtudiants', () => {
    let expectedEtudiants: Etud[];

    // @ts-ignore
    beforeEach(() => {
      etudService = TestBed.get(EtudiantsService);
      // @ts-ignore
      // @ts-ignore
      // @ts-ignore
      expectedEtudiants = [
        { id_etd: 1, nom_etd: 'A', prenom_etd: 'C', date_nais_etd: '04a', mail_etd: 'a@b',
          tel_etd: '+235', adresse_etd: {libelle_adr: 'NDJ'}},
        { id_etd: 2, nom_etd: 'O', prenom_etd: 'B', date_nais_etd: '24ba', mail_etd: 'pb@b',
          tel_etd: '+22235', adresse_etd: {libelle_adr: 'Hanoi'}},
        ] as Etud[];
    });

    // @ts-ignore
    it('should return expected etudiants (called once)', () => {

      etudService.getEtudiants().subscribe(
        etudiants => expect(etudiants).toEqual(expectedEtudiants, 'should return expected etudiants'),
        fail
      );

      /* // EtudService should have made one request to GET etudiants from expected URL */
      const req = httpTestingController.expectOne(etudService.etudiantsUrl);
      expect(req.request.method).toEqual('GET');

      // Respond with the mock heroes
      req.flush(expectedEtudiants);
    });

    // @ts-ignore
    it('should be OK returning no etudiants', () => {

      etudService.getEtudiants().subscribe(
        etudiants => expect(etudiants.length).toEqual(0, 'should have empty etudiants array'),
        fail
      );

      const req = httpTestingController.expectOne(etudService.etudiantsUrl);
      req.flush([]); // Respond with no etudiants
    });

    // This service reports the error but finds a way to let the app keep going.
    // @ts-ignore
    it('should turn 404 into an empty etudiants result', () => {

      etudService.getEtudiants().subscribe(
        etudiants => expect(etudiants.length).toEqual(0, 'should return empty heroes array'),
        fail
      );

      const req = httpTestingController.expectOne(etudService.etudiantsUrl);

      // respond with a 404 and the error message in the body
      const msg = 'deliberate 404 error';
      req.flush(msg, {status: 404, statusText: 'Not Found'});
    });

    // @ts-ignore
    it('should return expected heroes (called multiple times)', () => {

      etudService.getEtudiants().subscribe();
      etudService.getEtudiants().subscribe();
      etudService.getEtudiants().subscribe(
        etudiants => expect(etudiants).toEqual(expectedEtudiants, 'should return expected etudiants'),
        fail
      );

      const requests = httpTestingController.match(etudService.etudiantsUrl);
      expect(requests.length).toEqual(3, 'calls to getEtudiants()');

      // Respond to each request with different mock hero results
      requests[0].flush([]);
      requests[1].flush({ id_etd: 1, nom_etd: 'A', prenom_etd: 'C', date_nais_etd: '04a', mail_etd: 'a@b',
        tel_etd: '+235', adresse_etd: {libelle_adr: 'NDJ'}});
      requests[2].flush(expectedEtudiants);
    });
  });

  describe('#updateEtud', () => {
    // Expecting the query form of URL so should not 404 when id not found
    const makeUrl = (id_etd: number) => `${etudService.etudiantsUrl}/?id_etd=${id_etd}`;

    // @ts-ignore
    it('should update a hero and return it', () => {

      const updateEtud: Etud = { id_etd: 1, nom_etd: 'A', prenom_etd: 'C', date_nais_etd: '04a', mail_etd: 'a@b',
        tel_etd: '+235', adresse_etd: {libelle_adr: 'NDJ'}};
      etudService.update_etudiants(updateEtud).subscribe(data => expect(data).toEqual(updateEtud, 'should return the etud'),
        fail
      );

      // HeroService should have made one request to PUT hero
      const req = httpTestingController.expectOne(etudService.etudiantsUrl);
      expect(req.request.method).toEqual('PUT');
      expect(req.request.body).toEqual(updateEtud);

      // Expect server to return the hero after PUT
      const expectedResponse = new HttpResponse(
        { status: 200, statusText: 'OK', body: updateEtud });
      req.event(expectedResponse);
    });

    // This service reports the error but finds a way to let the app keep going.
    // @ts-ignore
    it('should turn 404 error into return of the update etud', () => {
      const updateEtud: Etud = { id_etd: 1, nom_etd: 'A', prenom_etd: 'C', date_nais_etd: '04a', mail_etd: 'a@b',
        tel_etd: '+235', adresse_etd: {libelle_adr: 'NDJ'}};

      etudService.update_etudiants(updateEtud).subscribe(
        data => expect(data).toEqual(updateEtud, 'should return the update etud'),
        fail
      );

      const req = httpTestingController.expectOne(etudService.etudiantsUrl);

      // respond with a 404 and the error message in the body
      const msg = 'deliberate 404 error';
      req.flush(msg, {status: 404, statusText: 'Not Found'});
    });
  });

  // TODO: test other EtudService methods
});
