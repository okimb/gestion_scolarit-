package com.ifi_gla.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Inscrire implements Serializable {
	@Id
	private String Code_ins;
	private Etudiant etudiant_ins;
	private Niveau niveau_ins;
	private Annee_Scolaire anne_scolaire_ins;
	private Payer_Scolarite payer_scolarite_ins;
	private Date date_ins;
	
	public String getCode_ins() {
		return Code_ins;
	}
	public void setCode_ins(String code_ins) {
		Code_ins = code_ins;
	}
	public Etudiant getEtudiant_ins() {
		return etudiant_ins;
	}
	public void setEtudiant_ins(Etudiant etudiant_ins) {
		this.etudiant_ins = etudiant_ins;
	}
	public Niveau getNiveau_ins() {
		return niveau_ins;
	}
	public void setNiveau_ins(Niveau niveau_ins) {
		this.niveau_ins = niveau_ins;
	}
	
	public Payer_Scolarite getPayer_scolarite_ins() {
		return payer_scolarite_ins;
	}
	public void setPayer_scolarite_ins(Payer_Scolarite payer_scolarite_ins) {
		this.payer_scolarite_ins = payer_scolarite_ins;
	}
	public Annee_Scolaire getAnne_scolaire_ins() {
		return anne_scolaire_ins;
	}
	public void setAnne_scolaire_ins(Annee_Scolaire anne_scolaire_ins) {
		this.anne_scolaire_ins = anne_scolaire_ins;
	}
	
	public Date getDate_ins() {
		return date_ins;
	}
	public void setDate_ins(Date date_ins) {
		this.date_ins = date_ins;
	}
	
	
	public Inscrire() {
		super();
	}
	public Inscrire(String code_ins, Etudiant etudiant_ins, Niveau niveau_ins, Annee_Scolaire anne_scolaire_ins,
			Payer_Scolarite payer_scolarite_ins, Date date_ins) {
		super();
		Code_ins = code_ins;
		this.etudiant_ins = etudiant_ins;
		this.niveau_ins = niveau_ins;
		this.anne_scolaire_ins = anne_scolaire_ins;
		this.payer_scolarite_ins = payer_scolarite_ins;
		this.date_ins = date_ins;
	} 

	
	
}
