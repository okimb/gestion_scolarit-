package com.ifi_gla.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Adresse implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String Code_adr;
	private String libelle_adr;
	@ManyToOne
	@JoinColumn(name="Id_etd")
	private Etudiant etudiant;
	
	public String getCode_adr() {
		return Code_adr;
	}
	public void setCode_adr(String code_adr) {
		Code_adr = code_adr;
	}
	public String getLibelle_adr() {
		return libelle_adr;
	}
	public void setLibelle_adr(String libelle_adr) {
		this.libelle_adr = libelle_adr;
	}
	public Etudiant getEtudiant() {
		return etudiant;
	}
	public void setEtudiant(Etudiant etudiant) {
		this.etudiant = etudiant;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	public Adresse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Adresse(String libelle_adr) {
		super();
		this.libelle_adr = libelle_adr;
	}
	
	
	
	public Adresse(String libelle_adr, Etudiant etudiant) {
		super();
		this.libelle_adr = libelle_adr;
		this.etudiant = etudiant;
	}
	public Adresse(String code_adr, String libelle_adr, Etudiant etudiant) {
		super();
		Code_adr = code_adr;
		this.libelle_adr = libelle_adr;
		this.etudiant = etudiant;
	}
	

}
