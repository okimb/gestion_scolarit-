package com.ifi_gla.controllers;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ifi_gla.dao.IAdresseRepository;
import com.ifi_gla.dao.IEtudiantRepository;
import com.ifi_gla.entities.Adresse;
import com.ifi_gla.entities.Etudiant;

@CrossOrigin(origins = "http://localhost:4200")
// @RequestMapping("/all")
@RestController
@RequestMapping ({ "/api" })
public class ifi_glaController {
	
	
	@Autowired
	private IEtudiantRepository etudiantRepository;
	@Autowired
	private IAdresseRepository adresseRepository;

	@RequestMapping("/save_etudiants")
	public Etudiant enregistrerEtudiant(Etudiant e) {
		etudiantRepository.save(e);
		return e;
	}

	@RequestMapping("/All")
	public java.util.List<Etudiant> getEtudiant(String sortField, String sort) {
		return etudiantRepository.findAll();
	}
	// Affichier la liste des étudiants par page
	@SuppressWarnings("deprecation")
	@RequestMapping("/etudiant")
	public Page<Etudiant> getEtudiant(Integer page){
		 return etudiantRepository.findAll(new PageRequest(page, 5));
		
	}
	
	// Afficher la liste des étudiants par page avec le mot clé mc
		@RequestMapping("/etudiantParMC")
		public Page<Etudiant> getEtudiant(String mc, int page){
			return etudiantRepository.etudiantParMC("%"+mc+"%", new PageRequest(page, 5));
		}
	
				
		@RequestMapping("/update_etudiants")
		public Etudiant update(Etudiant e){
			etudiantRepository.saveAndFlush(e);
			return e;
		}

		// Consulter un etudiant par matricule
		
		@RequestMapping("/getEtudiants")
		public Optional<Etudiant> getEtudiant(Long Id_etd){
			return etudiantRepository.findById(Id_etd);
		}
		
		@RequestMapping("/delete_etudiants")
		public boolean delete(Long Id_etd){
			etudiantRepository.deleteById(Id_etd);
			return true;
		}
		
		//////////////////////////////////////////////////////////:
		 @Autowired
	
		@RequestMapping(value="/")
		public String etudiant(Map<String , Object >map) {
		Etudiant etudiants =new Etudiant();
		map.put("etudiants", etudiants);
		map.put("etudiantsList", etudiantRepository.findAll());
		return"etudiant/etudiant";
		}
		
		@RequestMapping(value="/nouveau", method=RequestMethod.GET)
		public String AddEtudiant(Model model) {
			Etudiant etudiant=new Etudiant();
			model.addAttribute("etudiant", etudiant);
			return"etudiant/AddEtudiant";
		}
	/*	
		@RequestMapping(value="/nouveau", method=RequestMethod.POST)
		public String EnregistrerEtudiant(Etudiant etudiant) {
			
			 if(etudiant.getId_etd() !=null) {
				etudiantRepository.update(etudiant);
			}else {
				etudiantRepository.save(etudiant);
			}
			 return"redirect:/etudiant/";

			} */
		@RequestMapping(value="/modifier/{id_etd}")
		public String modifierEtudiant(Model model, @PathVariable Long id_etd) {
			
			if(id_etd !=null) {
				Etudiant etudiant=etudiantRepository.getOne(id_etd);
				
				if(etudiant !=null) {
					model.addAttribute("etudiant", etudiant);
				}
			}
			return "etudiant/AddEtudiant";
		}
		
		@RequestMapping(value="/supprimer/{id_etd}")
		public String supprimerEtudiant(Model model, @PathVariable Long id_etd) {
			if(id_etd !=null) {
				Etudiant etudiant=etudiantRepository.getOne(id_etd);
				if(etudiant !=null) {
					etudiantRepository.deleteById(id_etd);
				}
			}
			return "redirect:/etudiant/";
		}
		
		
		//////////////////////////////////////Adresse//////////////////////////////////////
		
		@RequestMapping("/save_ad")
		public Adresse enregistrerAdresse(Adresse a) {
			adresseRepository.save(a);
			return a;
		}
		
	
}
