package com.ifi_gla;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.rest.RepositoryRestMvcAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ifi_gla.controllers.ifi_glaController;
import com.ifi_gla.dao.IEtudiantRepository;
import com.ifi_gla.entities.Etudiant;

@SpringBootApplication
public class IfiGlaApplication implements CommandLineRunner {
	@Autowired
	private ifi_glaController ifi_glaController;
	@Autowired
	private IEtudiantRepository etudiantRepository;

	
	public static void main(String[] args) {
		SpringApplication.run(IfiGlaApplication.class, args);
		
	}
@Override

	public void run(String ... args) throws Exception{
	etudiantRepository.save(new Etudiant(null,"nom","Prenom", "Email", "5/4/2102", "33333","Ok"));
	}



}

