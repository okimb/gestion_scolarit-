/**
 * 
 */
package com.ifi_gla.dao;


import java.util.List;

// import java.util.List;

// import org.hibernate.annotations.ParamDef;
// import org.jboss.logging.Param;
import org.springframework.data.domain.Page;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.ifi_gla.entities.Etudiant;

// /** @CrossOrigin("http://localhost:4200")*/

/**
 * @author okimb
 *
 */
public interface IEtudiantRepository extends JpaRepository<Etudiant, Long>{
		
	
	@Query("select e from Etudiant e where e.prenom_etd like :x")
	public Page<Etudiant> etudiantParMC(@org.springframework.data.repository.query.Param("x")String mc,Pageable p);
//	public List<Etudiant> findByPrenom_etd(String pr_etd);
	//public Page<Etudiant> findByPrenom_etd(String p, Pageable p);
	@Query ("select e.id_etd from Etudiant e where e.prenom_etd like : x")
	public static int idEtudiant(@org.springframework.data.repository.query.Param("x")String prenom) {
	// TODO Auto-generated method stub
	return 0;
}
	
/* 	String prenom_etd;
	int idetd=idEtudiant(prenom_etd);
	@Query("select a from Adresses a where a.etudiants.id_etd like:" idEtudiant(x))
	
	public Page<Etudiant> liste_etudiants(@org.springframework.data.repository.query.Param(idEtudiant("x"))String mc,Pageable p); */
}
