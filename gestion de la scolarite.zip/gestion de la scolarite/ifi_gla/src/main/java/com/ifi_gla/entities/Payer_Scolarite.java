package com.ifi_gla.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Payer_Scolarite implements Serializable {
	@Id
	private String Cod_pay;
	private String libelle_pay;
	private Integer frais_tranche_pay;
	
	
	public String getCod_pay() {
		return Cod_pay;
	}
	public void setCod_pay(String cod_pay) {
		Cod_pay = cod_pay;
	}
	public String getLibelle_pay() {
		return libelle_pay;
	}
	public void setLibelle_pay(String libelle_pay) {
		this.libelle_pay = libelle_pay;
	}
	public Integer getFrais_tranche_pay() {
		return frais_tranche_pay;
	}
	public void setFrais_tranche_pay(Integer frais_tranche_pay) {
		this.frais_tranche_pay = frais_tranche_pay;
	}
	
	
	public Payer_Scolarite() {
		super();
	}
	
	public Payer_Scolarite(String cod_pay, String libelle_pay, Integer frais_tranche_pay) {
		super();
		Cod_pay = cod_pay;
		this.libelle_pay = libelle_pay;
		this.frais_tranche_pay = frais_tranche_pay;
	}
	
	
	
	
	
	

	
}
