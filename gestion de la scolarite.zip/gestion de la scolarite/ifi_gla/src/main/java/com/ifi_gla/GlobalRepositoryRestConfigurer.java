package com.ifi_gla;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;

import com.ifi_gla.entities.Adresse;
import com.ifi_gla.entities.Etudiant;

import org.springframework.data.jpa.repository.config.*;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurerAdapter;

@Configuration
public class GlobalRepositoryRestConfigurer extends RepositoryRestConfigurerAdapter {
	@Override
	public void configureRepositoryRestConfiguration(RepositoryRestConfiguration repositoryRestConfiguration) {
		repositoryRestConfiguration.setReturnBodyOnCreate(true);
		repositoryRestConfiguration.setReturnBodyOnUpdate(true);
		repositoryRestConfiguration.exposeIdsFor(Etudiant.class,Adresse.class);
		repositoryRestConfiguration.getCorsRegistry()
		.addMapping("/**")
		.allowedOrigins("*")
		.allowedHeaders("*")
		.allowedMethods("OPTION", "PUT", "POST", "HEAD", "GET", "DELETE", "PATCH");
		
		
		
		
	}
		
	   /* public void addCorsMappings(CorsRegistry registry) {
	    
	        registry.addMapping("/**").allowCredentials(false).allowedOrigins("http://localhost:4200").allowedMethods("PUT", "POST", "HEAD", "GET", "OPTIONS", "DELETE", "PATCH").exposedHeaders("Authorization", "Content-Type");
	   
	    }*/

	
}
