package com.ifi_gla.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ifi_gla.entities.Adresse;

public interface IAdresseRepository extends JpaRepository<Adresse, Long>{

}
