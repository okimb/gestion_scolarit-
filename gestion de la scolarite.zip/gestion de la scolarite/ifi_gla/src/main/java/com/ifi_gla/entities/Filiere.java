package com.ifi_gla.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Filiere implements Serializable {
	@Id
	private String Code_fil;
	private String libelle_fil;
	private Niveau niveau_fil;
	
	
	public String getCode_fil() {
		return Code_fil;
	}
	public void setCode_fil(String code_fil) {
		Code_fil = code_fil;
	}
	public String getLibelle_fil() {
		return libelle_fil;
	}
	public void setLibelle_fil(String libelle_fil) {
		this.libelle_fil = libelle_fil;
	}
	public Niveau getNiveau_fil() {
		return niveau_fil;
	}
	public void setNiveau_fil(Niveau niveau_fil) {
		this.niveau_fil = niveau_fil;
	}
	
	
	public Filiere() {
		super();
	}
	
	public Filiere(String code_fil, String libelle_fil, Niveau niveau_fil) {
		super();
		Code_fil = code_fil;
		this.libelle_fil = libelle_fil;
		this.niveau_fil = niveau_fil;
	} 
	
	
	
	
}
