package com.ifi_gla.services;

public class EtudiantServiceImpl {
	/*  @Autowired
	    private IEtudiantRepository etudiantRepository; */

	   
}