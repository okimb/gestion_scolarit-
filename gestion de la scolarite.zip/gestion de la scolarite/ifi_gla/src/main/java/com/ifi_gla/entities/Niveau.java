package com.ifi_gla.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Niveau implements Serializable {
	@Id
	private String Code_Niv;
	private String libelle_niv;
	
	
	public String getCode_Niv() {
		return Code_Niv;
	}
	public void setCode_Niv(String code_Niv) {
		Code_Niv = code_Niv;
	}
	public String getLibelle_niv() {
		return libelle_niv;
	}
	public void setLibelle_niv(String libelle_niv) {
		this.libelle_niv = libelle_niv;
	}
	
	
	public Niveau() {
		super();
	}
	public Niveau(String code_Niv, String libelle_niv) {
		super();
		Code_Niv = code_Niv;
		this.libelle_niv = libelle_niv;
	}
	
	

}
