package com.ifi_gla.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Annee_Scolaire implements Serializable {
	@Id
	private String Code_ann;
	private String libelle_ann;
	private String debut_ann;
	private String fin_ann;
	
	
	public String getCode_ann() {
		return Code_ann;
	}
	public void setCode_ann(String code_ann) {
		Code_ann = code_ann;
	}
	public String getLibelle_ann() {
		return libelle_ann;
	}
	public void setLibelle_ann(String libelle_ann) {
		this.libelle_ann = libelle_ann;
	}
	public String getDebut_ann() {
		return debut_ann;
	}
	public void setDebut_ann(String debut_ann) {
		this.debut_ann = debut_ann;
	}
	public String getFin_ann() {
		return fin_ann;
	}
	public void setFin_ann(String fin_ann) {
		this.fin_ann = fin_ann;
	}
	
	
	public Annee_Scolaire() {
		super();
	}
	
	public Annee_Scolaire(String code_ann, String libelle_ann, String debut_ann, String fin_ann) {
		super();
		Code_ann = code_ann;
		this.libelle_ann = libelle_ann;
		this.debut_ann = debut_ann;
		this.fin_ann = fin_ann;
	}
	
	
	
	

}
