package com.ifi_gla.entities;

import java.io.Serializable;
import java.util.Collection;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.beans.factory.annotation.Autowired;
@Entity
public class Etudiant implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long Id_etd;
	private String nom_etd;
	private String prenom_etd;
	private String date_nais_etd;
	private String mail_etd;
	private String tel_etd;
	private String lib_add_etd;
	@Autowired
	@OneToMany(mappedBy="etudiant")
	private Collection<Adresse> adresse_etd;
	
	
	//private Adresse adresse_etd;
	public Long getId_etd() {
		return Id_etd;
	}
	public void setId_etd(Long id_etd) {
		Id_etd = id_etd;
	}
	public String getNom_etd() {
		return nom_etd;
	}
	public void setNom_etd(String nom_etd) {
		this.nom_etd = nom_etd;
	}
	public String getPrenom_etd() {
		return prenom_etd;
	}
	public void setPrenom_etd(String prenom_etd) {
		this.prenom_etd = prenom_etd;
	}
	public String getDate_nais_etd() {
		return date_nais_etd;
	}
	public void setDate_nais_etd(String date_nais_etd) {
		this.date_nais_etd = date_nais_etd;
	}
	public String getMail_etd() {
		return mail_etd;
	}
	public void setMail_etd(String mail_etd) {
		this.mail_etd = mail_etd;
	}
	public String getTel_etd() {
		return tel_etd;
	}
	public void setTel_etd(String tel_etd) {
		this.tel_etd = tel_etd;
	}
	public String getLib_add_etd() {
		return lib_add_etd;
	}
	public void setLib_add_etd(String lib_add_etd) {
		this.lib_add_etd = lib_add_etd;
	}
	public Collection<Adresse> getAdresse_etd() {
		return adresse_etd;
	}
	public void setAdresse_etd(Collection<Adresse> adresse_etd) {
		this.adresse_etd = adresse_etd;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	public Etudiant() {
		super();
	}
	public Etudiant(Long id_etd, String nom_etd, String prenom_etd, String date_nais_etd, String mail_etd,
			String tel_etd, String lib_add_etd, Collection<Adresse> adresse_etd) {
		super();
		Id_etd = id_etd;
		this.nom_etd = nom_etd;
		this.prenom_etd = prenom_etd;
		this.date_nais_etd = date_nais_etd;
		this.mail_etd = mail_etd;
		this.tel_etd = tel_etd;
		this.lib_add_etd = lib_add_etd;
		this.adresse_etd = adresse_etd;
	}
	public Etudiant(Long id_etd, String nom_etd, String prenom_etd, String date_nais_etd, String mail_etd,
			String tel_etd, String lib_add_etd) {
		super();
		Id_etd = id_etd;
		this.nom_etd = nom_etd;
		this.prenom_etd = prenom_etd;
		this.date_nais_etd = date_nais_etd;
		this.mail_etd = mail_etd;
		this.tel_etd = tel_etd;
		this.lib_add_etd = lib_add_etd;
	}
	
	public Etudiant(String nom_etd, String prenom_etd, String date_nais_etd, String mail_etd, String tel_etd,
			String lib_add_etd) {
		super();
		this.nom_etd = nom_etd;
		this.prenom_etd = prenom_etd;
		this.date_nais_etd = date_nais_etd;
		this.mail_etd = mail_etd;
		this.tel_etd = tel_etd;
		this.lib_add_etd = lib_add_etd;
	}
	

	

}
